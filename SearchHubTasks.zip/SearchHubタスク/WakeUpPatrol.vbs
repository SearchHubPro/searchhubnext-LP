Set ws = CreateObject("WScript.Shell")

' NEXTのページをChromeで開く（拡張機能はこのページを目印に動きます）
ws.Run "chrome.exe ""https://searchhubpro.github.io/searchhubnext-desktop/"""

' Chromeが開き切るまで待つ。遅いパソコンなら 4000 を 6000 などに増やしてください
WScript.Sleep 4000

' スタートメニューなどが出ていたら消して、Chromeを最前面に出す
ws.SendKeys "{ESC}"
ws.AppActivate "Google Chrome"
